from contextlib import _RedirectStream
#from matplotlib import image
import numpy as np
import xgboost as xgb
#from PIL import Image
from werkzeug.utils import secure_filename
from flask import Flask, request, render_template, Markup
from keras.applications.imagenet_utils import preprocess_input, decode_predictions
import pickle
from keras.models import load_model
import os
import cv2
import requests
#from gevent.pywsgi import WSGIServer

disease_class = ['black_pod_rot',
                   'healthy',
                   'pod_borer']

#prediction_model = load_model('models/Val_Loss.h5')
#model = load_model('models/V3model.pkl')
model_pred = pickle.load(open('models/V3_model', "rb"))



app = Flask(__name__)

def predict_image(img_path, prediction_model):

    img = cv2.imread(img_path, cv2.IMREAD_COLOR)       
    img = cv2.resize(img, (255, 255))
    img = cv2.cvtColor(img, cv2.COLOR_RGB2BGR)
    img = np.array(img)

    input_img = np.expand_dims(img, axis=0)
    input_img = input_img.reshape(255, 255)
    #input_img_feature=VGG_model.predict(input_img)
    prediction = model_pred.predict(img)
    
    return prediction

@ app.route('/')
def home():
    title = 'Cacao Detector - Home'
    return render_template('index.html', title=title)

@app.route('/weather-forecast', methods=['GET', 'POST'])
def weather_forecast():
    title = 'Weather Forecast'

    if request.method == "POST":
        city = request.form['city']
        country = request.form['country']
        api_key = "f715b7b79f16e44dd99ff15ed6aa5c78"

        weather_url = requests.get(
            f'http://api.openweathermap.org/data/2.5/weather?appid={api_key}&q={city},{country}&units=imperial')

        weather_data = weather_url.json()

        temp = round(weather_data['main']['temp'])
        humidity = weather_data['main']['humidity']
        wind_speed = weather_data['wind']['speed']

        return render_template('weather_result.html', temp=temp, humidity=humidity, wind_speed=wind_speed, city=city)

    return render_template('weather.html', title=title)

@app.route('/disease-predict', methods=['GET', 'POST'])
def disease_prediction():
    title = 'Cacao Detector - Disease Detection'
    
    if request.method == 'POST':
        if 'file' not in request.files:
            return _RedirectStream(request.url)
        file = request.files.get('file')
        if not file:
            return render_template('disease.html', title=title)
        try:
            img = file.read()
            prediction = predict_image(img)
            prediction = Markup(str([prediction]))
            return render_template('disease-result.html', prediction=prediction, title=title)
        except:
            pass
    return render_template('disease.html', title=title)    
if __name__=='__main__':
    app.run(debug=True, port=6683)
























#    if request.method == 'POST':
#        # get the file from post request
#        f=request.files['file']
#        basepath=os.path.dirname(os.path.realpath('__file__'))
#        file_path=os.path.join(basepath,'uploads',secure_filename(f.filename))
#        f.save(file_path)
#        
#        if file_path not in request.files:
#            return _RedirectStream(request.url)        
#        if not f:
#            return render_template('disease.html', title=title)
#        try:
#            img  = file_path.read()   
#            result =model_predict(image, model)
#            #pred_class = result.argmax()
#            #output=categories[pred_class]
#        except:
#            pass
#        return None
#    return render_template('disease_base.html', title=title)
#if __name__=='__main__':
#    app.run(debug=True, port=6683)
